from django.apps import AppConfig


class AcadsConfig(AppConfig):
    name = 'acads'
